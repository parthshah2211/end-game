@extends('layouts.admin')
@section('content')
    <div class="admin-title">
        <span>Welcome to Admin Panel !!</span>
    </div>

@endsection
