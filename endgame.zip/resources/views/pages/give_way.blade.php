@extends('layouts.app')

<style>
    div.gallery {
        border: 1px solid #ccc;
        margin-top: 20PX;
        margin-left: 20px;
        margin-bottom: 20px;
        margin-right: 20px;
    }

    div.gallery:hover {
        border: 1px solid #777;
    }

    div.gallery img {
        width: 100%;
        height: 40%;
    }

    div.desc {
        padding: 15px;
        text-align: center;
        background-color: rgba(101,6,126,1);
    }

    * {
        box-sizing: border-box;
    }

    .responsive {
        padding: 0 6px;
        float: left;
        width: 24.99999%;
    }

    @media only screen and (max-width: 700px) {
        .responsive {
            width: 49.99999%;
            margin: 6px 0;
        }
    }

    @media only screen and (max-width: 500px) {
        .responsive {
            width: 100%;
        }
    }

    .clearfix:after {
        content: "";
        display: table;
        clear: both;

</style>
@section('content')

    <!-- Page top section -->
    <section class="page-top-section set-bg" data-setbg="{{asset('img/page-top-bg/3.jpg')}}
    ">
        <div class="page-info">
            <h2>GIVE-WAY</h2>
            <div class="site-breadcrumb">
                <a>GIVE -WAY</a>
                <span></span>
            </div>
        </div>
    </section>
    <!-- Page top end-->

@if(isset($giveways))
    @foreach($giveways as $giveway)
        <div class="responsive">
            <div class="gallery">
                <a target="_blank" href="{{asset('uploads/'.$giveway['image'])}}">
                    <img src="{{asset('uploads/'.$giveway['image'])}}" alt="Cinque Terre" width="600" height="400">
                </a>
                <div class="desc"> <h4 style="color:white; size: auto">{{$giveway['title']}}</h4>
                    <h5 style="color:white";> Registration Date:{{$giveway['registration_date']}}</h5>
                    <h5 style="color:white";> Announcement Date:{{$giveway['announcement_date']}}</h5>
                    <p style="color:black"; >{{$giveway['description']}}</p>
                </div>
                {{--        <button type="button" class="btn btn-primary" style="margin-left: 251.5px">Primary</button>--}}
            </div>
        </div>
        @endforeach
@else
    <h5 class="text-center">There is No Give-Way Right Now !!!</h5>
    @endif


<div class="clearfix"></div>

    <!-- Page top end-->
