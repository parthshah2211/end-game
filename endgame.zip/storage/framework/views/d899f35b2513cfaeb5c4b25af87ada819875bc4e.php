<?php $__env->startSection('content'); ?>
    <div class="add_btn">
        <a href="<?php echo e(url('admin/giveaway/create')); ?>" class="btn btn-success">Add GiveAway</a>
    </div>
    <div class="container-fluid">

        <table class="table table-bordered" id="table">
            <thead>
            <tr>
                <th class="text-nowrap">Title</th>
                <th class="text-nowrap">Registration Date</th>
                <th>Announcement Date</th>
                <th>Category</th>
                <th>Description</th>
            </tr>
            </thead>
        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('section-js'); ?>
    <script type="text/javascript">
        $(function () {
            $('#table').DataTable({
                processing: true,
                serverSide: true,
                ajax: '<?php echo e(url('admin/get-giveaway-data')); ?>',
                columns: [
                    { data: 'title', name: 'title' },
                    { data: 'registration_date', name: 'registration_date' },
                    { data: 'announcement_date', name: 'announcement_date' },
                    { data: 'category', name: 'category' },
                    { data: 'description', name: 'description' }
                ]
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\endgame\resources\views/pages/admin/giveaway.blade.php ENDPATH**/ ?>