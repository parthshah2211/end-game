<?php $__env->startSection('content'); ?>
  <div class="add_btn">
      <a href="<?php echo e(url('admin/tournament/create')); ?>" class="btn btn-success">Add Tournament</a>
  </div>
    <div class="container-fluid">

        <table class="table table-bordered" id="table">
            <thead>
            <tr>
                <th class="text-nowrap">Tournament Name</th>
                <th class="text-nowrap">Tournament Date</th>
                <th>Category</th>
                <th>Type</th>
                <th class="text-nowrap">Price Type</th>
                <th class="text-nowrap">Price Pool</th>
                <th>Description</th>
            </tr>
            </thead>
        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('section-js'); ?>
<script type="text/javascript">
    $(function () {
        $('#table').DataTable({
            processing: true,
            serverSide: true,
            ajax: '<?php echo e(url('admin/get-tournament-data')); ?>',
            columns: [
                { data: 'name', name: 'name' },
                { data: 'date', name: 'date' },
                { data: 'category', name: 'category' },
                { data: 'type', name: 'type' },
                { data: 'price_type', name: 'price_type' },
                {data:'price_pool',name:'price_pool'},
                { data: 'description', name: 'description' }
            ]
        });
    });
</script>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\endgame\resources\views/pages/admin/tournament.blade.php ENDPATH**/ ?>