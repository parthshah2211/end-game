<?php $__env->startSection('content'); ?>
    <div class="admin-title">
        <span>Welcome to Admin Panel !!</span>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\endgame\resources\views/pages/admin/main.blade.php ENDPATH**/ ?>