<style>
    div.gallery {
        border: 1px solid #ccc;
        margin-top: 20PX;
        margin-left: 20px;
        margin-bottom: 20px;
        margin-right: 20px;
    }

    div.gallery:hover {
        border: 1px solid #777;
    }

    div.gallery img {
        width: 100%;
        height: 40%;
    }

    div.desc {
        padding: 15px;
        text-align: center;
        background-color: rgba(101,6,126,1);
    }

    * {
        box-sizing: border-box;
    }

    .responsive {
        padding: 0 6px;
        float: left;
        width: 24.99999%;
    }

    @media  only screen and (max-width: 700px) {
        .responsive {
            width: 49.99999%;
            margin: 6px 0;
        }
    }

    @media  only screen and (max-width: 500px) {
        .responsive {
            width: 100%;
        }
    }

    .clearfix:after {
        content: "";
        display: table;
        clear: both;

</style>
<?php $__env->startSection('content'); ?>

    <!-- Page top section -->
    <section class="page-top-section set-bg" data-setbg="<?php echo e(asset('img/page-top-bg/3.jpg')); ?>

    ">
        <div class="page-info">
            <h2>GIVE-WAY</h2>
            <div class="site-breadcrumb">
                <a>GIVE -WAY</a>
                <span></span>
            </div>
        </div>
    </section>
    <!-- Page top end-->

<?php if(isset($giveways)): ?>
    <?php $__currentLoopData = $giveways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $giveway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="responsive">
            <div class="gallery">
                <a target="_blank" href="<?php echo e(asset('uploads/'.$giveway['image'])); ?>">
                    <img src="<?php echo e(asset('uploads/'.$giveway['image'])); ?>" alt="Cinque Terre" width="600" height="400">
                </a>
                <div class="desc"> <h4 style="color:white; size: auto"><?php echo e($giveway['title']); ?></h4>
                    <h5 style="color:white";> Registration Date:<?php echo e($giveway['registration_date']); ?></h5>
                    <h5 style="color:white";> Announcement Date:<?php echo e($giveway['announcement_date']); ?></h5>
                    <p style="color:black"; ><?php echo e($giveway['description']); ?></p>
                </div>
                
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <h5 class="text-center">There is No Give-Way Right Now !!!</h5>
    <?php endif; ?>


<div class="clearfix"></div>

    <!-- Page top end-->

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\endgame\resources\views/pages/give_way.blade.php ENDPATH**/ ?>