<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!--====== Javascripts & Jquery ======-->


    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

    <!-- Stylesheets -->

    <link rel="stylesheet" href="<?php echo e(asset('css/main-site/font-awesome.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('css/main-site/slicknav.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('css/main-site/owl.carousel.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('css/main-site/magnific-popup.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('css/main-site/animate.css')); ?>"/>

    <!-- Main Stylesheets -->
    <link rel="stylesheet" href="<?php echo e(asset('css/main-site/style.css')); ?>"/>


    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
<div id="app">

     <?php echo $__env->make('common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(\Illuminate\Support\Facades\Route::current()->getName() !== 'login' &&  \Illuminate\Support\Facades\Route::current()->getName() !== 'register'): ?>
        <?php echo $__env->make('common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>



</div>

<!--====== Javascripts & Jquery ======-->
<script src="<?php echo e(asset('js/jquery-3.2.1.min.js')); ?>"></script>

<script src="<?php echo e(asset('js/jquery.slicknav.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.sticky-sidebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/main.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\endgame\resources\views/layouts/app.blade.php ENDPATH**/ ?>