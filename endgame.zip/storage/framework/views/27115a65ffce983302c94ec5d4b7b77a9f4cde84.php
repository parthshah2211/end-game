<!-- Header section -->
<header class="header-section">
    <div class="header-warp">

        <div class="header-bar-warp d-flex">
            <!-- site logo -->
            <a href="home.html" class="site-logo">
                <img src="<?php echo e(asset('img/logo.png')); ?>" alt="">
            </a>
            <nav class="top-nav-area w-100">
                <div class="user-panel">
                    <?php if(auth()->guard()->guest()): ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>
                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>" style="padding-left: 10px">Register</a>
                        <?php endif; ?>
                    <?php else: ?>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>

                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                                                     document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                      style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                    <?php endif; ?>

                </div>
                <!-- Menu -->
                <!-- Menu -->
                <ul class="main-menu primary-menu">
                    <li><a href="/">Home</a></li>
                    <li><a href="">Tournamnet</a>
                        <ul class="sub-menu">
                            <li><a href="<?php echo e(url('/tournament')); ?>" >free fite </a></li>


                            <li><a href="<?php echo e(url('/tournament')); ?>">PUBG</a></li>
                            <li><a href="<?php echo e(url('/tournament')); ?>">COD</a></li>
                        </ul>
                    </li>
                    <li><a href="review.html">screems</a>
                        <ul class="sub-menu">
                            <li><a href="screms.html">Free-Fire</a></li>


                            <li><a href="screms.html">PUBG</a>
                                <ul class="sub-menu">
                                    <li><a href="screms.html">free</a>
                                    </li>

                                </ul>
                            <li><a href="game-single.html">COD</a></li>
                        </ul>
                    </li>
                    <li><a href="<?php echo e(url('/give_way')); ?>">Give-Way</a>
                        <ul class="sub-menu">
                            <li><a href="<?php echo e(url('/give_way/free-fire')); ?>">Free-Fire</a></li>


                            <li><a href="<?php echo e(url('/give_way')); ?>">PUBG</a></li>
                            <li><a href="<?php echo e(url('/give_way')); ?>">COD</a></li>
                        </ul>
                    </li>
                    <li><a href="<?php echo e(url('/News')); ?>">News</a>
                        <ul class="sub-menu">
                            <li><a href="<?php echo e(url('/News')); ?>">Free-Fire</a></li>


                            <li><a href="News.html">PUBG</a></li>
                            <li><a href="News.html">COD</a></li>
                        </ul>
                    </li>

                    <li><a href="<?php echo e(('/contact')); ?>">Contact</a></li>
                </ul>
            </nav>
        </div>
    </div>
</header>
<!-- Header section end -->
<?php /**PATH C:\xampp\htdocs\endgame\resources\views/common/header.blade.php ENDPATH**/ ?>