<link href="<?php echo e(asset('css/login.css')); ?>" rel="stylesheet">
<?php $__env->startSection('content'); ?>
    <div class="padding-all">
        <div class="header">
            <h1><img class="text-center" src="<?php echo e(asset('images/5.png')); ?>" alt=" "></h1>
        </div>

        <div class="design-w3l">
            <div class="mail-form-agile">
                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="text" id="email" name="email" placeholder="User Name  or  email..." required=""/>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="error" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="password"  id="password" name="password" class="padding" placeholder="Password" required=""/>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="error" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <button type="submit">Submit</button>
                </form>
            </div>
            <div class="clear"> </div>
        </div>

        <div class="footer">
            <p>Create an Account <a>  Register </a></p>
        </div>
    </div>







































































<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\endgame\resources\views/auth/login.blade.php ENDPATH**/ ?>